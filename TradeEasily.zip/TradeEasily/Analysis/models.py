from django.db import models

# Create your models here.
# models.py
'''class SupportResistanceLevel(models.Model):
    support = models.FloatField()
    resistance = models.FloatField()'''

class SupportResistance(models.Model):
    option = models.CharField(max_length=20, choices=[('nifty', 'Nifty'), ('banknifty', 'BankNifty')])
    date = models.DateField()
    #support = models.ManyToManyField(SupportResistanceLevel, related_name='support_levels')
    #resistance = models.ManyToManyField(SupportResistanceLevel, related_name='resistance_levels')
    support=models.TextField(max_length=100,null=False)
    resistance=models.TextField(max_length=100,null=False)

    class Meta:
        unique_together = (('option', 'date'),)
