from rest_framework import serializers
from .models import SupportResistance

class SupportResistanceSerializer(serializers.ModelSerializer):
    #support = serializers.PrimaryKeyRelatedField(many=True, queryset=SupportResistanceLevel.objects.all())
    #resistance = serializers.PrimaryKeyRelatedField(many=True, queryset=SupportResistanceLevel.objects.all())

    class Meta:
        model = SupportResistance
        fields = '__all__'


class JSONFileSerializer(serializers.Serializer):
    time = serializers.CharField()
    pcr = serializers.FloatField()