from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import SupportResistanceViewSet,JSONFileView
from . import views

router = DefaultRouter()
router.register('support_resistance', SupportResistanceViewSet, basename='support_resistance')
#router.register('support_resistance_levels',TextFileViewSet,basename='support_resistance_levels')
urlpatterns = [
    path('', include(router.urls)),
    path('api/pcr/', JSONFileView.as_view()),

]