
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer
from rest_framework.views import APIView
from .models import SupportResistance
from .serializers import SupportResistanceSerializer,JSONFileSerializer
from django.http import FileResponse,JsonResponse
import json
from .serializers import JSONFileSerializer


class SupportResistanceViewSet(viewsets.ModelViewSet):
    queryset = SupportResistance.objects.all()
    serializer_class = SupportResistanceSerializer

    def get_queryset(self):
        option = self.request.query_params.get('option', None)
        date = self.request.query_params.get('date', None)
        queryset = SupportResistance.objects.filter(date=date)
        if option is not None:
            queryset = queryset.filter(option=option)
        return queryset

class JSONFileView(APIView):
    renderer_classes = [JSONRenderer]

    def get(self, request):
        with open('C:\\Users\\UX504088\\Desktop\\Trading\\TradeEasily\\TradeEasily\\Analysis\\pcr.json', 'r') as file:
            file_contents = json.load(file)
       
        serializer = JSONFileSerializer(data=file_contents,many=True)
        serializer.is_valid(raise_exception=True)
        return Response(serializer.data)
