def PCR_Live():
    import requests
    import time
    import json
    from datetime import datetime
    from bs4 import BeautifulSoup
    url = 'https://www.moneycontrol.com/markets/fno-market-snapshot'
    response = requests.get(url)
    html_content = response.content
    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find("table", {"class": "tbl_fno"})
    rows = table.find_all("tr")
    # Extract the open interest PCR data from the rows
    data = []
    for row in rows:
        cells = row.find_all("td")
        if len(cells) > 0:
            pcr = cells[1].text
            data.append(pcr)
    
   # Saving data to a JSON file
    pcr_data = data[5]
    print(pcr_data)
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    data = {'time': current_time, 'pcr': pcr_data}

    # read the existing data from the file
    try:
        with open('pcr.json', 'r') as file:
            existing_data = json.load(file)
    except:
        existing_data = []

    # append the new data to the existing data
    existing_data.append(data)

    # write the updated data to the file
    with open('pcr.json', 'w') as file:
        json.dump(existing_data, file, indent=4)


    return data



#Main Software Window
import tkinter as tk
root = tk.Tk()
root.geometry("700x500")

label = tk.Label(root, text="Welcome to Trading")
label.pack()

result_label = tk.StringVar()
label = tk.Label(root, textvariable=result_label)
label.pack()

pcr_button  = tk.Button(root, text="Want PCR!", command=lambda: result_label.set(PCR_Live()))
pcr_button.pack()



root.mainloop()



    